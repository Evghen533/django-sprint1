import os
import sys
from pathlib import Path


def main():
    # ЭТА СТРОКА ОБЯЗАТЕЛЬНА: она говорит Django, где лежат настройки
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "blogicum.settings")

    BASE_DIR = Path(__file__).resolve().parent
    if str(BASE_DIR) not in sys.path:
        sys.path.insert(0, str(BASE_DIR))

    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc

    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
